CREATE PROCEDURE deptandpepole()
  BEGIN
     # 声明判断游标数据为空的标量
     DECLARE done BOOLEAN DEFAULT 0;
     # 声明接受dept.name的局部变量
     DECLARE dname VARCHAR(20);
     # 声明接受pepole.old的局部变量
     # DECLARE dold INT;
     
     # 声明游标
     DECLARE deptname_pepoleold CURSOR
     FOR
     SELECT name FROM dept;
     # 声明 continue handler
     DECLARE CONTINUE HANDLER FOR SQLSTATE '02000' SET done = 1;
     
     #编写sql语句用于查询数据
     # SELECT old FROM pepole INTO dold;
     
     # 如果表不存在则创建表
     CREATE TABLE IF NOT EXISTS newdeptpo(
            name VARCHAR(20)
     );
     # 打开游标
     OPEN deptname_pepoleold;
     # 循环遍历游标
     REPEAT
           FETCH deptname_pepoleold INTO dname;
           INSERT INTO newdeptpo(name) VALUES(dname);
     UNTIL done END REPEAT;
     # 关闭游标 
     CLOSE deptname_pepoleold;
END;

