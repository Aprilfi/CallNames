CREATE PROCEDURE deptid()
  BEGIN
     #定义局部变量接受检索数据
     DECLARE o INT;
     #创建游标
     DECLARE deptids CURSOR
     FOR
     SELECT id FROM dept;
     #打开游标
     OPEN deptids;
     FETCH deptids INTO o;
     
     #关闭游标
     CLOSE deptids;

END;

