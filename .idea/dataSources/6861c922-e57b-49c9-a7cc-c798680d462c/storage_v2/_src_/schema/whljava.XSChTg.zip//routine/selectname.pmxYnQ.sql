CREATE PROCEDURE selectname(OUT sname VARCHAR(20), OUT sold INT)
  BEGIN
     SELECT name INTO sname FROM dept WHERE name='苏缪文1';
     SELECT old INTO sold FROM pepole WHERE old=17;
END;

